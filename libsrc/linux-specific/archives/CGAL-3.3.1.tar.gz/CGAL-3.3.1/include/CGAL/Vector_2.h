// Copyright (c) 1999  Utrecht University (The Netherlands),
// ETH Zurich (Switzerland), Freie Universitaet Berlin (Germany),
// INRIA Sophia-Antipolis (France), Martin-Luther-University Halle-Wittenberg
// (Germany), Max-Planck-Institute Saarbruecken (Germany), RISC Linz (Austria),
// and Tel-Aviv University (Israel).  All rights reserved.
//
// This file is part of CGAL (www.cgal.org); you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public License as
// published by the Free Software Foundation; version 2.1 of the License.
// See the file LICENSE.LGPL distributed with CGAL.
//
// Licensees holding a valid commercial license may use this file in
// accordance with the commercial license agreement provided with the software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
// WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
//
// $URL: svn+ssh://scm.gforge.inria.fr/svn/cgal/branches/CGAL-3.3-branch/Kernel_23/include/CGAL/Vector_2.h $
// $Id: Vector_2.h 37197 2007-03-17 18:29:25Z afabri $
//
//
// Author(s)     : Andreas Fabri, Stefan Schirra

#ifndef CGAL_VECTOR_2_H
#define CGAL_VECTOR_2_H

#include <CGAL/Origin.h>
#include <CGAL/Kernel/mpl.h>
#include <boost/static_assert.hpp>
#include <boost/type_traits.hpp>
#include <CGAL/Kernel/Return_base_tag.h>
#include <CGAL/representation_tags.h>

CGAL_BEGIN_NAMESPACE

template <class R_>
class Vector_2 : public R_::Kernel_base::Vector_2
{
  typedef typename R_::RT             RT;
  typedef typename R_::FT             FT;
  typedef typename R_::Segment_2      Segment_2;
  typedef typename R_::Ray_2          Ray_2;
  typedef typename R_::Line_2         Line_2;
  typedef typename R_::Point_2        Point_2;
  typedef typename R_::Direction_2    Direction_2;
  typedef typename R_::Aff_transformation_2  Aff_transformation_2;
  typedef typename R_::Kernel_base::Vector_2  RVector_2;

  typedef Vector_2                    Self;
  BOOST_STATIC_ASSERT((boost::is_same<Self, typename R_::Vector_2>::value));

public:

  typedef RVector_2 Rep;

  const Rep& rep() const
  {
    return *this;
  }

  Rep& rep()
  {
    return *this;
  }

  typedef  R_                        R;

  Vector_2() {}

  Vector_2(const RVector_2& v)
      : RVector_2(v) {}

  Vector_2(const Point_2& a, const Point_2& b)
      : RVector_2(typename R::Construct_vector_2()(Return_base_tag(), a, b)) {}

  Vector_2(const Segment_2 &s)
      : RVector_2(typename R::Construct_vector_2()(Return_base_tag(), s)) {}

  Vector_2(const Ray_2 &r)
      : RVector_2(typename R::Construct_vector_2()(Return_base_tag(), r)) {}

  Vector_2(const Line_2 &l)
      : RVector_2(typename R::Construct_vector_2()(Return_base_tag(), l)) {}

  Vector_2(const Null_vector &v)
      : RVector_2(typename R::Construct_vector_2()(Return_base_tag(), v)) {}

  template < typename T1, typename T2 >
#ifdef __INTEL_COMPILER
      Self
#else
  Vector_2
#endif
          (const T1 &x, const T2 &y)
      : RVector_2(typename R::Construct_vector_2()(Return_base_tag(), x,y)) {}

  Vector_2(const RT &x, const RT &y, const RT &w)
      : RVector_2(typename R::Construct_vector_2()(Return_base_tag(), x,y,w)) {}


  typename Qualified_result_of<typename R::Compute_x_2,Vector_2>::type
  x() const
  {
    return R().compute_x_2_object()(*this);
  }

  typename Qualified_result_of<typename R::Compute_y_2,Vector_2>::type
  y() const
  {
    return R().compute_y_2_object()(*this);
  }

  typename Qualified_result_of<typename R::Compute_y_2,Vector_2>::type
  cartesian(int i) const
  {
    CGAL_kernel_precondition( (i == 0) || (i == 1) );
    return (i==0) ?  x() : y();
  }

  typename Qualified_result_of<typename R::Compute_x_2,Vector_2>::type
  operator[](int i) const
  {
      return cartesian(i);
  }

  typename Qualified_result_of<typename R::Compute_hx_2,Vector_2>::type
  hx() const
  {
    return R().compute_hx_2_object()(*this);
  }


  typename Qualified_result_of<typename R::Compute_hy_2,Vector_2>::type
  hy() const
  {
    return R().compute_hy_2_object()(*this);
  }

  typename Qualified_result_of<typename R::Compute_hw_2,Vector_2>::type
  hw() const
  {
    return R().compute_hw_2_object()(*this);
  }

  typename Qualified_result_of<typename R::Compute_hx_2,Vector_2>::type
  homogeneous(int i) const
  {
    CGAL_kernel_precondition( (i >= 0) || (i <= 2) );
    return (i==0) ?  hx() : (i==1)? hy() : hw();
  }

  int dimension() const
  {
      return 2;
  }

  Vector_2 operator-() const
  {
    return R().construct_opposite_vector_2_object()(*this);
  }

  Vector_2 operator-(const Vector_2& v) const
  {
    return R().construct_difference_of_vectors_2_object()(*this,v);
  }

  Vector_2 operator+(const Vector_2& v) const
  {
    return R().construct_sum_of_vectors_2_object()(*this,v);
  }

  Vector_2 operator/(const RT& c) const
  {
   return R().construct_divided_vector_2_object()(*this,c);
  }

  Vector_2 operator/(const typename First_if_different<FT,RT>::Type & c) const
  {
   return R().construct_divided_vector_2_object()(*this,c);
  }

  FT squared_length() const
  {
    return R().compute_squared_length_2_object()(*this);
  }


  Direction_2 direction() const
  {
    return R().construct_direction_2_object()(*this);
  }

  Vector_2 perpendicular(const Orientation &o) const
  {
    return R().construct_perpendicular_vector_2_object()(*this,o);
  }

  Vector_2 transform(const Aff_transformation_2 &t) const
  {
    return t.transform(*this);
  }

};


template < class R >
inline
bool
operator==(const Vector_2<R> &v, const Null_vector &n)
{
  return R().equal_2_object()(v, n);
}

template < class R >
inline
bool
operator==(const Null_vector &n, const Vector_2<R> &v)
{
  return v == n;
}

template < class R >
inline
bool
operator!=(const Vector_2<R> &v, const Null_vector &n)
{
  return !(v == n);
}

template < class R >
inline
bool
operator!=(const Null_vector &n, const Vector_2<R> &v)
{
  return !(v == n);
}


template <class R >
std::ostream&
insert(std::ostream& os, const Vector_2<R>& v, const Cartesian_tag&)
{
    switch(os.iword(IO::mode)) {
    case IO::ASCII :
        return os << v.x() << ' ' << v.y();
    case IO::BINARY :
        write(os, v.x());
        write(os, v.y());
        return os;
    default:
        return os << "VectorC2(" << v.x() << ", " << v.y() << ')';
    }
}

template <class R >
std::ostream&
insert(std::ostream& os, const Vector_2<R>& v, const Homogeneous_tag&)
{
  switch(os.iword(IO::mode))
  {
    case IO::ASCII :
        return os << v.hx() << ' ' << v.hy() << ' ' << v.hw();
    case IO::BINARY :
        write(os, v.hx());
        write(os, v.hy());
        write(os, v.hw());
        return os;
    default:
        return os << "VectorH2(" << v.hx() << ", "
                                 << v.hy() << ", "
                                 << v.hw() << ')';
  }
}

template < class R >
std::ostream&
operator<<(std::ostream& os, const Vector_2<R>& v)
{
  return insert(os, v, typename R::Kernel_tag() );
}



template <class R >
std::istream&
extract(std::istream& is, Vector_2<R>& v, const Cartesian_tag&)
{
    typename R::FT x, y;
    switch(is.iword(IO::mode)) {
    case IO::ASCII :
        is >> x >> y;
        break;
    case IO::BINARY :
        read(is, x);
        read(is, y);
        break;
    default:
        std::cerr << "" << std::endl;
        std::cerr << "Stream must be in ascii or binary mode" << std::endl;
        break;
    }
    if (is)
        v = Vector_2<R>(x, y);
    return is;
}


template <class R >
std::istream&
extract(std::istream& is, Vector_2<R>& v, const Homogeneous_tag&)
{
  typename R::RT hx, hy, hw;
  switch(is.iword(IO::mode))
  {
    case IO::ASCII :
        is >> hx >> hy >> hw;
        break;
    case IO::BINARY :
        read(is, hx);
        read(is, hy);
        read(is, hw);
        break;
    default:
        std::cerr << "" << std::endl;
        std::cerr << "Stream must be in ascii or binary mode" << std::endl;
        break;
  }
  v = Vector_2<R>(hx, hy, hw);
  return is;
}

template < class R >
std::istream&
operator>>(std::istream& is, Vector_2<R>& v)
{
  return extract(is, v, typename R::Kernel_tag() );
}

CGAL_END_NAMESPACE

#endif // CGAL_VECTOR_2_H
