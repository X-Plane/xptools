#include "Nef_type_fwd.h"

void gl_render_nef_facets(Nef_polyhedron* poly);
void gl_render_nef_edges(Nef_polyhedron* poly);
void gl_render_nef_vertices(Nef_polyhedron* poly);
