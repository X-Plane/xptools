#include "Polyhedron_type_fwd.h"
#include "Textured_polyhedron_type.h"

void gl_render_polyhedron_facets(Polyhedron* poly);
void gl_render_tex_polyhedron_facets(Textured_polyhedron* poly);
void gl_render_polyhedron_edges(Polyhedron *poly);
