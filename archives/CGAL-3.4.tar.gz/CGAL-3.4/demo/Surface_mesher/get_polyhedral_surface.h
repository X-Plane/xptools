#ifndef _GET_POLYHEDRAL_SURFACE_H
#define _GET_POLYHEDRAL_SURFACE_H

#include "surface.h"

Surface* get_polyhedral_surface(QObject*, double, double);

#endif // _GET_POLYHEDRAL_SURFACE_H
