// Only needed for Custom Build step with moc in the vcproj file
