/* For compatibility with early OpenGL ES 1.0 implementations that
 * included gl.h in egl.h (and apps that only included egl.h)
 * See: http://www.khronos.org/registry/implementers_guide.html
 */
#include <EGL/egl.h>
#include <GLES/gl.h>
